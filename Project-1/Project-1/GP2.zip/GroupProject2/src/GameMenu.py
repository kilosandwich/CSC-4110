import tkinter as tk

class GameMenu():
    def __init__(self):
        pass