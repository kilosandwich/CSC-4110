license = """By using this software you agree not to sell or distribute 
data without the express consent of Forestview 
You hereby indemnify Forestview from all legal ramnifications 
regarding data breaches, zero-day attacks, and database worms. 
Vendors are required to make periodic vulnerability 
assessments of this system. This agreement is subject 
to change, and will change to stay accurate with the 
current security and technology climate."""